const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('node:path');
const crypto = require('node:crypto');
const fs = require('node:fs');

function accountFile() {
  return path.join(app.getPath('userData'), 'local-account.json');
}
function readAccount() {
  try { return JSON.parse(fs.readFileSync(accountFile(), 'utf8')); }
  catch { return null; }
}
function writeAccount(data) {
  fs.mkdirSync(path.dirname(accountFile()), { recursive: true });
  fs.writeFileSync(accountFile(), JSON.stringify(data, null, 2), { mode: 0o600 });
}
function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 960, minHeight: 640,
    backgroundColor: '#101018',
    title: 'W.Edit',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}
app.whenReady().then(() => {
  ipcMain.handle('account:signup', (_event, { username, password }) => {
    username = String(username || '').trim();
    password = String(password || '');
    if (!/^[a-zA-Z0-9_.-]{3,24}$/.test(username))
      return { ok: false, message: 'Username must be 3–24 characters: letters, numbers, dot, dash or underscore.' };
    if (password.length < 10)
      return { ok: false, message: 'Use a password with at least 10 characters.' };
    if (readAccount())
      return { ok: false, message: 'A local prototype account already exists on this computer.' };
    const salt = crypto.randomBytes(16).toString('hex');
    writeAccount({ username, salt, passwordHash: hashPassword(password, salt) });
    return { ok: true, username };
  });
  ipcMain.handle('account:login', (_event, { username, password }) => {
    const account = readAccount();
    if (!account) return { ok: false, message: 'No local account yet. Please sign up first.' };
    const salt = account.salt;
    const candidate = Buffer.from(hashPassword(String(password || ''), salt), 'hex');
    const stored = Buffer.from(account.passwordHash, 'hex');
    const matches = candidate.length === stored.length && crypto.timingSafeEqual(candidate, stored);
    if (String(username || '').trim().toLowerCase() !== account.username.toLowerCase() || !matches)
      return { ok: false, message: 'Username or password is incorrect.' };
    return { ok: true, username: account.username };
  });
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
