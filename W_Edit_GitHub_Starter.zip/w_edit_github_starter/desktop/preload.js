const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('weditAccount', {
  signup: (data) => ipcRenderer.invoke('account:signup', data),
  login: (data) => ipcRenderer.invoke('account:login', data)
});
